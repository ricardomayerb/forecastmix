function [max_stat, p_value] = maxtest_generic_v1(y, Z, X, ndraws, heteroflag)
% PURPOSE: Run max test with common regressors Z and key regressors X.       
%--------------------------------------------------------------------
% USAGE: [max_stat, p_value] = maxtest_generic_v1(y, Z, X, ndraws, heteroflag)
% where: y = regressand (n x 1) 
%                  n = sample size
%        Z = common regressors (n x p)
%                  p = dimension of common regressors (small)
%        X = key regressors (n x h)
%                  h = dimension of key regressors (large)
%                  H0: all of X has zero coefficients
%        ndraws = # of draws from the limit distribution under H0 (scalar)
%        heteroflag = 1 if you do not assume conditional homoskedasticity
%                     0 if you assume conditional homoskedasticity
%--------------------------------------------------------------------
% RETURNS: max_stat = test statistic (scalar)
%          pval = approximate p-value (scalar)
%--------------------------------------------------------------------
% References: E. Ghysels, J. B. Hill, and K. Motegi (2018).  
%    Testing a Large Set of Zero Restrictions in Regression Models, 
%    with an Application to Mixed Frequency Granger Causality. 
%    Working paper at the University of North Carolina at Chapel Hill
%    and Kobe University.
% -------------------------------------------------------------------
% Model: y(t) = alpha(1) * z(1t) + ... + alpha(p) * z(pt) 
%                  + beta(i) * x(it) + u(t) for i = 1, ..., h
%--------------------------------------------------------------------
% See also: mvnrnd.m (Statistics and Machine Learning Toolbox)
% --------------------------------------------------------------------
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University. 
% December 29, 2018. 
% --------------------------------------------------------------------

n = size(X,1);     % sample size
h = size(X,2);     % dimension of key regressors
p = size(Z,2);     % dimension of common regressors

% run parsimonious regression models
beta_hats = zeros(h,1);
for i = 1:h
     regressors = [Z, X(:,i)];
     theta_hat = regressors \ y;
     beta_hat = theta_hat(end);
     beta_hats(i) = beta_hat;
end

max_stat = max(n * beta_hats.^2);   % max test statistic
 
alpha_hat_H0 = Z \ y;                   % run restricted regression 
resid_H0 = y - Z * alpha_hat_H0;        % residual from the restricted regression
sigsq_hat = (1/n) * sum(resid_H0.^2);   % error variance estimator under H0
S_hat_4D = zeros(p+1, p+1, h, h);       % covaraince matrices of regressors
for j = 1:h
     regressors_j = [Z, X(:,j)];
     Gamma_jj_hat = (1/n) * (regressors_j' * regressors_j);
     Gamma_jj_hat_inv = Gamma_jj_hat \ eye(p+1);
     for i = 1:h
          if i < j
              S_hat_4D(:,:,i,j) = S_hat_4D(:,:,j,i)';
          else    
              regressors_i = [Z, X(:,i)];
              Gamma_ii_hat = (1/n) * (regressors_i' * regressors_i);
              if heteroflag == 1
                  resid_H0_repmat = repmat(resid_H0, 1, p+1);
                  Lambda_ij_hat = (1/n) * ((resid_H0_repmat .* regressors_i)' * (resid_H0_repmat .* regressors_j)); 
              elseif heteroflag == 0    
                  Lambda_ij_hat = sigsq_hat * (1/n) * (regressors_i' * regressors_j);
              end    
              Gamma_ii_hat_inv = Gamma_ii_hat \ eye(p+1);
              Sigma_ij = Gamma_ii_hat_inv * Lambda_ij_hat * Gamma_jj_hat_inv;
              S_hat_4D(:,:,i,j) = Sigma_ij;
          end    
     end    
end    

% reshape S_hat_4D
S_hat = zeros((p+1)*h, (p+1)*h);
for i = 1:h
     first_row = (i-1) * (p+1) + 1;
     last_row = i * (p+1);
     for j = 1:h
          first_col = (j-1) * (p+1) + 1;
          last_col = j * (p+1);
          S_hat(first_row:last_row, first_col:last_col) = S_hat_4D(:,:,i,j);
     end    
end    

% construct selection matrix
R = zeros(h, (p+1)*h);
for i = 1:h
     indicator = i * (p+1);
     R(i,indicator) = 1;
end    

V_hat = R * S_hat * R';    % asymptotic covariance matrix

N = mvnrnd(zeros(h,1), V_hat, ndraws);   % draws from the limit distribution (ndraws x h)
Nsq = N.^2;
sim_draws = max(Nsq, [], 2);             % ndraws x 1
p_value = (1/ndraws) * sum(sim_draws > max_stat);      % p-value

