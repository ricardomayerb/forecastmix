
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eric Ghysels, Jonathan B. Hill, and Kaiji Motegi (2018). 
%    Testing a Large Set of Zero Restrictions in Regression Models, 
%         with an Application to Mixed Frequency Granger Causality.
%    Working paper at the University of North Carolina at Chapel Hill
%         and Kobe University.
%
% Main Matlab codes for Monte Carlos simulations with simple setting.
%
% *****************************************************
% Subroutines directly used in this main code:
%    (1) maxtest_all_zeros_v2.m 
%    (2) waldtest_all_zeros_v2.m 
%
% Further codes used in the subroutines above: None.
% *****************************************************
%
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University.
% 
% Last updated: February 15, 2018. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;    % erase everything
clc;          % clear command window

tic;                                           % start timing
start_date = now;                              % start date
disp(['Job started: ', datestr(start_date)]);  % display start date

%% Step 0: Initial Setting
J = 1000;                   % # of Monte Carlo samples
h = 100;                     % # of regressors
n = 10 * h;                 % sample size
DGP_type = 3;               % DGP type = {1, 2, 3, 4}
                            % DGP-1: true_betas = zeros(h,1)
                            % DGP-2: true_betas = b * [zeros(0.9*h,1); (10/h) * ones(0.1*h, 1)]
                            % DGP-3: true_betas = b * [zeros(0.5*h,1); (2/h) * ones(0.5*h, 1)]
                            % DGP-4: true_betas = b * (1/h) * ones(h,1)
rho = 0.3;                    % correlation coefficient between an arbitrary pair of regressors
b = 0.2;                    % the impact of X on y
bsnum = 1000;               % # of bootstrap samples (bootstrapped Wald test)
ndraws = 5000;              % # of draws from the limit distribution (max test)
tdist_error_flag = 0;       % 1 if error follows t-distribution
                            % 0 if error follows normal distribution
dof_error = 5;              % degrees of freedom of t-distribution (tdist_error_flag = 1)
tdist_regressor_flag = 0;   % 1 if regressors follow t-distribution
                            % 0 if regressors follow normal distribution
dof_regressor = 5;          % degrees of freedom of t-distribution (tdist_regressor_flag = 1)
GARCH_error_flag = 0;       % 1 if error follows GARCH
                            % 0 if error is IID
sigsq_eps = 1;              % variance of error (GARCH_error_flag = 0)
alpha = 0.3;                % ARCH parameter (GARCH_error_flag = 1)
beta = 0.6;                 % GARCH parameter (GARCH_error_flag = 1)
omega = 1 - alpha - beta;   % constant term in GARCH specification (GARCH_error_flag = 1)
nominal_size = 0.05;        % nominal size

%% Step1: Run Monte Carlo Simulations
if DGP_type == 1
    true_betas = zeros(h,1);     % true beta
elseif DGP_type == 2
    true_betas = b * [(10/h) * ones(0.1*h, 1); zeros(0.9*h,1)];     % true beta
elseif DGP_type == 3
    true_betas = b * [(2/h) * ones(0.5*h, 1); zeros(0.5*h,1)];     % true beta  
elseif DGP_type == 4
    true_betas = b * (1/h) * ones(h,1);     % true beta
end

% construct correlation matrix of regressors
covmat_X_temp = tril(rho * ones(h, h), -1);
covmat_X = eye(h) + covmat_X_temp + covmat_X_temp';

rejections_max_homo = zeros(J,1);
rejections_max_hetero = zeros(J,1);
rejections_wald_asy = zeros(J,1);
rejections_wald_bs = zeros(J,1);
parfor j = 1:J
%for j = 1:J
     % generate pure shocks
     if tdist_error_flag == 1
         nu = trnd(dof_error, n, 1);
     elseif tdist_error_flag == 0    
         nu = randn(n,1);
     end    

     % generate IID or GARCH error
     if GARCH_error_flag == 1
         epsilon = nu;
         sigsq = omega;
         for t = 2:n
              sigsq = omega + alpha * epsilon(t-1)^2 + beta * sigsq;
              epsilon(t) = sqrt(sigsq) * nu(t);
         end    
     elseif GARCH_error_flag == 0
         epsilon = sqrt(sigsq_eps) * nu;
     end

     % generate regressors
     if tdist_regressor_flag == 1
         X = mvtrnd(covmat_X, dof_regressor, n);
     elseif tdist_regressor_flag == 0    
         X = mvnrnd(zeros(h,1), covmat_X, n); 
     end         
     
     % generate regressand
     y = X * true_betas + epsilon;
     
     % run max test with the assumption of conditional homoskedasticity
     maxtest_hetero_flag = 0;
     [~, p_value_max_homo] = maxtest_all_zeros_v2(y, X, ndraws, maxtest_hetero_flag);
     rejections_max_homo(j) = (p_value_max_homo < nominal_size);

     % run max test without the assumption of conditional homoskedasticity
     maxtest_hetero_flag = 1;
     [~, p_value_max_hetero] = maxtest_all_zeros_v2(y, X, ndraws, maxtest_hetero_flag);
     rejections_max_hetero(j) = (p_value_max_hetero < nominal_size);     
     
     % run asymptotic Wald test 
     [wald_stat_asy, p_value_wald_asy] = waldtest_all_zeros_v2(y, X, 0);
     rejections_wald_asy(j) = (p_value_wald_asy < nominal_size);

     % run bootstrapped Wald test
      [wald_stat_bs, p_value_wald_bs] = waldtest_all_zeros_v2(y, X, bsnum);
      rejections_wald_bs(j) = (p_value_wald_bs < nominal_size);
end    

% compute rejection frequencies
rfreq_max_homo = (1/J) * sum(rejections_max_homo);
rfreq_max_hetero = (1/J) * sum(rejections_max_hetero);
rfreq_wald_asy = (1/J) * sum(rejections_wald_asy);
rfreq_wald_bs = (1/J) * sum(rejections_wald_bs);
rfreq_table = [rfreq_max_homo; rfreq_max_hetero; rfreq_wald_asy; rfreq_wald_bs];

%% Step 2: Report Computational Time 
time = toc;         % finish timing
end_date = now;     % end date
disp('*****************************************');
disp(['Job started: ', datestr(start_date)]);
disp(['Job finished: ', datestr(end_date)]);
disp(['Computational time: ', num2str(time), ' seconds.']);
disp(['Computational time: ', num2str(time / 60), ' minutes.']);
disp(['Computational time: ', num2str(time / 3600), ' hours.']);
disp('*****************************************');
disp(' ');

