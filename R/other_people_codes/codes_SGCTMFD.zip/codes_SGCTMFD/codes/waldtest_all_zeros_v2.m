function [wald_stat, p_value] = waldtest_all_zeros_v2(y, X, bsnum)
% PURPOSE: Perform asymptotic or bootstrapped Wald tests for joint zero 
%          restrictions.          
%--------------------------------------------------------------------
% USAGE: [wald_stat, p_value] = waldtest_all_zeros_v2(y, X, bsnum)
% where: y = regressand (n x 1) 
%        X = regressors (n x h)
%        bsnum = # bootstrap samples (1 x 1)
%                0 if asymptotic test is used
%            where: n = sample size
%                   h = # regressors = # parsimonious regression models
%--------------------------------------------------------------------
% RETURNS: wald_stat = test statistic (1 x 1)
%          p_value = asymptotic or bootstrapped p-value (1 x 1)
%--------------------------------------------------------------------
% References: 
%    E. Ghysels, J. B. Hill and K. Motegi (2018). Testing a Large Set of 
%        Zero Restrictions in Regression Models, with an Application to 
%        Mixed Frequency Granger Causality. Working paper at the University
%        of North Carolina at Chapel Hill and Kobe University.
%    S. Goncalves and L. Kilian (2004). Bootstrapping Autoregressions with 
%        Conditional Heteroskedasticity of Unknown Form. Journal of
%        Econometrics, 123, 89-120.
% -------------------------------------------------------------------
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University.
% Last updated: February 15, 2018. 
% --------------------------------------------------------------------

% sub-routine that computes a Wald test statistic
function [wald_stat, resid, n, h] = wald_test_stat(y, X)
    n = size(X,1);             % sample size
    h = size(X,2);             % # regressors
    beta_hat = X \ y;          % OLS estimator
    resid = y - X * beta_hat;                            % residual
    sigsq_hat = (1/n) * sum(resid.^2);                   % variance of residual
    Sigma_X_hat = (1/n) * (X' * X);                      % covariance matrix
    Sigma_X_hat_inv = Sigma_X_hat \ eye(h);
    V_hat = sigsq_hat * Sigma_X_hat_inv;
    V_hat_inv = V_hat \ eye(h);
    wald_stat = n * beta_hat' * V_hat_inv * beta_hat;    % test statistic
end

[wald_stat, resid, n, h] = wald_test_stat(y, X);    % Wald test statistic
 
if bsnum == 0   % do not run bootstrap
    p_value = 1 - chi2cdf(wald_stat, h);   % asymptotic p-value
else            % run Goncalves and Kilian's (2004) bootstrap with bsnum replications
    counter = 0;
    for j = 1:bsnum
         xi = randn(n,1);
         xi_epsilon = xi .* resid;
         y_bs = xi_epsilon;
         wald_stat_bs = wald_test_stat(y_bs, X);
         counter = counter + (wald_stat_bs > wald_stat);
    end     
    p_value = (1/bsnum) * counter;        % bootstrapped p-value
end

end
    
