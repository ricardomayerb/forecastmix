
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eric Ghysels, Jonathan B. Hill, and Kaiji Motegi (2018). 
%    Testing a Large Set of Zero Restrictions in Regression Models, 
%         with an Application to Mixed Frequency Granger Causality.
%    Working paper at the University of North Carolina at Chapel Hill
%         and Kobe University.
%
% Main Matlab codes for empirical application on weekly yield spread 
%    and quarterly GDP growth in the U.S.
% Drawing p-values of max and Wald tests across rolling windows.  
%
% *****************************************************
% Data:
%    (1) pvalue_rolling_window_v1.txt
% Subroutines directly used in this main code: None.
% Further codes used in the subroutines above: None.
% *****************************************************
%
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University.
% Last updated: February 15, 2018. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all      % erase everything
close all      % close all figures
clc            % clear command window

% default settings for figures
% Font settings are particularly important. Without them there will be an error 
% when you try to open eps files via GS View.
set(0, 'DefaultAxesFontName', 'Helvetica');
set(0, 'DefaultTextFontName', 'Helvetica');
set(0, 'DefaultAxesFontSize', 14); 
set(0, 'DefaultTextFontSize', 14); 
set(gcf,'DefaultLineLineWidth', 1.5);

%% Step 1: Load Data
directory_name = 'E:\SGCTMFD\Mat_Code\';   % where to save figures
version_number = 1;

load pvalue_rolling_window_v1.txt
dates_serial_xls = pvalue_rolling_window_v1(:,1);     % date labels in Excel format
pval_MF_max = pvalue_rolling_window_v1(:,2);          % MF max test
pval_MF_wald = pvalue_rolling_window_v1(:,3);         % MF Wald test
pval_LF_max = pvalue_rolling_window_v1(:,4);          % LF max test
pval_LF_wald = pvalue_rolling_window_v1(:,5);         % LF Wald test
nominal_size = pvalue_rolling_window_v1(:,6);         % nominal size (0.05)
dates_serial_matlab = x2mdate(dates_serial_xls);      % % transform the date labels from Excel format to Matlab format

dateFormat = 10;    % format of dates on x-axis 
                    % 10 = 2005; 12 = Jan05.
   
%% Step 2: Plot Figures                    
figure(1)      % MF max test
width = 4;
hold on 
bar(dates_serial_matlab, nominal_size, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
plot(dates_serial_matlab, pval_MF_max, '-k*', 'LineWidth', 1.8, 'MarkerSize', 4);     % price
hold off
box on
datetick('x', dateFormat);
xlim([dates_serial_matlab(1), dates_serial_matlab(end)]);
ylim([0, 1]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'on';
file_name = strcat('pvalue_MF_max_v', num2str(version_number));
print('-depsc2', strcat(directory_name, file_name));          

figure(2)     % MF Wald test
width = 4;
hold on 
bar(dates_serial_matlab, nominal_size, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
plot(dates_serial_matlab, pval_MF_wald, '-k*', 'LineWidth', 1.8, 'MarkerSize', 4);     % price
hold off
box on
datetick('x', dateFormat);
xlim([dates_serial_matlab(1), dates_serial_matlab(end)]);
ylim([0, 1]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'on';
file_name = strcat('pvalue_MF_wald_v', num2str(version_number));
print('-depsc2', strcat(directory_name, file_name));      

figure(3)     % LF max test
width = 4;
hold on 
bar(dates_serial_matlab, nominal_size, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
plot(dates_serial_matlab, pval_LF_max, '-k*', 'LineWidth', 1.8, 'MarkerSize', 4);     % price
hold off
box on
datetick('x', dateFormat);
xlim([dates_serial_matlab(1), dates_serial_matlab(end)]);
ylim([0, 1]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'on';
file_name = strcat('pvalue_LF_max_v', num2str(version_number));
print('-depsc2', strcat(directory_name, file_name));      

figure(4)     % LF Wald test
width = 4;
hold on 
bar(dates_serial_matlab, nominal_size, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
plot(dates_serial_matlab, pval_LF_wald, '-k*', 'LineWidth', 1.8, 'MarkerSize', 4);     % price
hold off
box on
datetick('x', dateFormat);
xlim([dates_serial_matlab(1), dates_serial_matlab(end)]);
ylim([0, 1]);
ax = gca;
ax.XGrid = 'on';
ax.YGrid = 'on';
file_name = strcat('pvalue_LF_wald_v', num2str(version_number));
print('-depsc2', strcat(directory_name, file_name));      

