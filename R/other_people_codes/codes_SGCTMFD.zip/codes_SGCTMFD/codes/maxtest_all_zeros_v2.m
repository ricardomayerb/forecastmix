function [max_stat, p_value] = maxtest_all_zeros_v2(y, X, ndraws, heteroflag)
% PURPOSE: Perform max tests for joint zero restrictions.          
%--------------------------------------------------------------------
% USAGE: [max_stat, p_value] = maxtest_all_zeros_v2(y, X, ndraws, heteroflag)
% where: y = regressand (n x 1) 
%        X = regressors (n x h)
%        ndraws = # draws from asymptotic distribution under H0 (1 x 1)           
%        heteroflag = 1 if conditional homoskedasticity is NOT assumed.
%                     0 if conditional homoskedasticity is assumed.
%            where: n = sample size
%                   h = # regressors = # parsimonious regression models
%--------------------------------------------------------------------
% RETURNS: max_stat = test statistic (1 x 1)
%          p_value = simulated p-value (1 x 1)
%--------------------------------------------------------------------
% References: 
%    E. Ghysels, J. B. Hill and K. Motegi (2018). Testing a Large Set of 
%        Zero Restrictions in Regression Models, with an Application to 
%        Mixed Frequency Granger Causality. Working paper at the University
%        of North Carolina at Chapel Hill and Kobe University.
% -------------------------------------------------------------------
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University.
% Last updated: February 15, 2018. 
% --------------------------------------------------------------------

n = size(X,1);     % sample size
h = size(X,2);     % dimension of regressors

% run parsimonious regression models
beta_hats = zeros(h,1);
for i = 1:h
     X_temp = X(:,i);
     beta_hat = X_temp \ y;
     beta_hats(i) = beta_hat;
end

max_stat = max(n * beta_hats.^2);    % max-test statistic
 
% compute a core part of covariance matrix 
sigsq_hat = (1/n) * sum(y.^2);
S_hat = zeros(h,h);
for j = 1:h
     x_j = X(:,j);
     Gamma_jj_hat = (1/n) * sum(x_j.^2);
     for i = 1:h
          if i < j
              S_hat(i,j) = S_hat(j,i);
          else    
              x_i = X(:,i);
              Gamma_ii_hat = (1/n) * sum(x_i.^2);
              if heteroflag == 1
                  Lambda_ij_hat = (1/n) * sum((y.^2) .* x_j .* x_i); 
              elseif heteroflag == 0    
                  Lambda_ij_hat = sigsq_hat * (1/n) * sum(x_j .* x_i);
              end    
              Sigma_ij = Gamma_ii_hat^(-1) * Lambda_ij_hat * Gamma_jj_hat^(-1);
              S_hat(i,j) = Sigma_ij;
          end    
     end    
end    

R = eye(h);
V_hat = R * S_hat * R';    % asymptotic covariance matrix (h x h)

% draw from the asymptotic distribution under H0
N = mvnrnd(zeros(h,1), V_hat, ndraws);    % ndraws x h
Nsq = N.^2;
sim_draws = max(Nsq, [], 2);              % ndraws x 1
p_value = (1/ndraws) * sum(sim_draws > max_stat);    % simulated p-value

