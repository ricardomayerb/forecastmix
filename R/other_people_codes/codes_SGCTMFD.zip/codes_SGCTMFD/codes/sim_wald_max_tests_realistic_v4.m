
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eric Ghysels, Jonathan B. Hill, and Kaiji Motegi (2018). 
%    Testing a Large Set of Zero Restrictions in Regression Models, 
%         with an Application to Mixed Frequency Granger Causality.
%    Working paper at the University of North Carolina at Chapel Hill
%         and Kobe University.
%
% Main Matlab codes for Monte Carlos simulations with empirical setting.
%
% *****************************************************
% Subroutines directly used in this main code:
%    (1) maxtest_all_zeros_v2.m 
%    (2) waldtest_all_zeros_v2.m 
%
% Further codes used in the subroutines above: None.
% *****************************************************
%
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University.
% Last updated: February 15, 2018. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;    % erase everything
clc;          % clear command window

tic;                                           % start timing
start_date = now;                              % start date
disp(['Job started: ', datestr(start_date)]);  % display start date

%% Step 0: Initial Setting
J = 1000;                % # of Monte Carlo samples
m = 12;                  % ratio of sampling frequencies
h_MF = 24;               % # of regressors (mixed frequency models)
h_LF = 3;                % # of regressors (low frequency models)
T = 200;                  % low frequency sample size
DGP_type = 4;            % DGP type = {1, 2, 3, 4}
                         % DGP-1: true_betas = zeros(h,1)
                         % DGP-2: true_betas = b * [(1/3) * ones(3,1); zeros(21,1)]
                         % DGP-3: true_betas = b * [(2/h_MF) * ones(0.5*h_MF, 1); zeros(0.5*h_MF,1)]
                         % DGP-4: true_betas = b * (1/h_MF) * ones(h_MF,1)
phi_H = 0.95;            % AR(1) coefficient for x_H
phi_L = 0.85;            % AR(1) coefficient for x_L
b = 0.1;                 % parameter on high-to-low causality
c = 0;                   % true constant
nlags_LF = 2;            % # of lags of X_L included in the MF and LF models
bsnum = 1000;            % # of bootstrap samples (bootstrapped Wald test)
ndraws = 5000;           % # of draws from the limit distribution (max test)
nominal_size = 0.05;     % nominal size

%% Step1: Run Monte Carlo Simulations
mT = m * T;                                   % high frequency sample size
nlag = max([nlags_LF, ceil(h_MF/m), h_LF]);   % # of observations discarded
nobs = T - nlag;                              % effective low frequency sample size 

% true causal patterns 
if DGP_type == 1
    true_betas = zeros(h_MF,1);      % non-causality
elseif DGP_type == 2
    true_betas = b * [(1/3) * ones(3,1); zeros(21,1)];     
elseif DGP_type == 3
    true_betas = b * [(2/h_MF) * ones(0.5*h_MF, 1); zeros(0.5*h_MF,1)];       
elseif DGP_type == 4
    true_betas = b * (1/h_MF) * ones(h_MF,1);
end

rejections_max_hetero = zeros(J,1);
rejections_wald_asy = zeros(J,1);
rejections_wald_bs = zeros(J,1);
rejections_max_hetero_LF = zeros(J,1);
rejections_wald_asy_LF = zeros(J,1);
rejections_wald_bs_LF = zeros(J,1);
parfor j = 1:J
%for j = 1:J
     epsilon_H = randn(mT,1);    % generate errors for x_H
     x_H = zeros(mT,1);          % generate x_H from high frequency AR(1)
     for t = 2:mT
          x_H(t) = phi_H * x_H(t-1) + epsilon_H(t); 
     end    
     
     epsilon_L = randn(T,1);     % generate errors for x_L
     x_L = zeros(T,1);           % generate x_L
     for tau = 2:T
          t_newest = (tau - 1) * m;         % newest high frequency lag given tau
          t_oldest = t_newest - h_MF + 1;   % oldest high frequency lag given tau
          if t_oldest >= 1       % all lags of x_H exist
              x_H_temp = x_H(t_oldest:t_newest);
              x_L(tau) = c + phi_L * x_L(tau-1) + true_betas' * flipud(x_H_temp) + epsilon_L(tau);
          else                   % some lags of x_H do not exist
              x_H_temp = x_H(1:t_newest);
              x_L(tau) = c + phi_L * x_L(tau-1) + true_betas(1:t_newest)' * flipud(x_H_temp) + epsilon_L(tau);
          end    
     end    
     
     x_H_mat = reshape(x_H, m, T)';      % x_H in matrix form (T x m)
     x_H_agg = x_H_mat(:,m);             % aggregated x_H with stock sampling (T x 1)
     x_H_agg_lags = zeros(nobs, h_LF);   % lags of aggregated x_H (nobs x h_LF)
     for k = 1:h_LF
          x_H_agg_lags(:,k) = x_H_agg((nlag+1-k):(T-k));
     end    
     
     y = x_L((nlag + 1):T);          % regressand (nobs x 1)
     Z = zeros(nobs, nlags_LF+1);    % common regressors (nobs x (nlags_LF + 1))
     Z(:,1) = 1;
     for k = 1:nlags_LF
          Z(:,k+1) = x_L((nlag+1-k):(T-k)); 
     end    
     
     X = zeros(nobs, h_MF);          % key regressors in mixed frequency models (nobs x h_MF)
     for tau = 1:nobs
          counter_LF = 0;
          counter_HF = 0;
          for k = 1:h_MF
               X(tau,k) = x_H_mat(nlag + tau - 1 - counter_LF, m - counter_HF);
               if m - counter_HF == 1   % update both high frequency and low frequency arguments of x_H
                   counter_HF = 0;
                   counter_LF = counter_LF + 1; 
               else                     % update only high frequency argument of x_H
                   counter_HF = counter_HF + 1;
               end    
          end              
     end    
     
     % run max test without the assumption of conditional homoskedasticity (mixed frequency)
     maxtest_hetero_flag = 1;
     [~, p_value_max_hetero] = maxtest_generic_v1(y, Z, X, ndraws, maxtest_hetero_flag);
     rejections_max_hetero(j) = (p_value_max_hetero < nominal_size);     

     % run asymptotic Wald test (mixed frequency)
     [~, p_value_wald_asy] = waldtest_ARp_v1(y, X, nlags_LF, 0);
     rejections_wald_asy(j) = (p_value_wald_asy < nominal_size);

     % run bootstrapped Wald test (mixed frequency)
     [~, p_value_wald_bs] = waldtest_ARp_v1(y, X, nlags_LF, bsnum);
     rejections_wald_bs(j) = (p_value_wald_bs < nominal_size);
     
     % run max test without the assumption of conditional homoskedasticity (low frequency)
     maxtest_hetero_flag = 1;
     [~, p_value_max_hetero_LF] = maxtest_generic_v1(y, Z, x_H_agg_lags, ndraws, maxtest_hetero_flag);
     rejections_max_hetero_LF(j) = (p_value_max_hetero_LF < nominal_size);     

     % run asymptotic Wald test (low frequency)
     [~, p_value_wald_asy_LF] = waldtest_ARp_v1(y, x_H_agg_lags, nlags_LF, 0);
     rejections_wald_asy_LF(j) = (p_value_wald_asy_LF < nominal_size);

     % run bootstrapped Wald test (low frequency)
     [~, p_value_wald_bs_LF] = waldtest_ARp_v1(y, x_H_agg_lags, nlags_LF, bsnum);
     rejections_wald_bs_LF(j) = (p_value_wald_bs_LF < nominal_size);     
end    

% compute rejection frequencies
rfreq_max_hetero = (1/J) * sum(rejections_max_hetero);        % rejection frequency of max test (mixed frequency)
rfreq_wald_asy = (1/J) * sum(rejections_wald_asy);            % rejection frequency of asymptotic Wald test (mixed frequency)
rfreq_wald_bs = (1/J) * sum(rejections_wald_bs);              % rejection frequency of bootstrapped Wald test (mixed frequency)
rfreq_max_hetero_LF = (1/J) * sum(rejections_max_hetero_LF);  % rejection frequency of max test (low frequency)
rfreq_wald_asy_LF = (1/J) * sum(rejections_wald_asy_LF);      % rejection frequency of asymptotic Wald test (low frequency)
rfreq_wald_bs_LF = (1/J) * sum(rejections_wald_bs_LF);        % rejection frequency of bootstrapped Wald test (low frequency)
rfreq_table = [rfreq_max_hetero, rfreq_max_hetero_LF; 
                 rfreq_wald_asy,   rfreq_wald_asy_LF; 
                  rfreq_wald_bs,    rfreq_wald_bs_LF];        % table of rejection frequencies

%% Step 2: Report Computational Time 
time = toc;      % finish timing
end_date = now;  % end date
disp('*****************************************');
disp(['Job started: ', datestr(start_date)]);
disp(['Job finished: ', datestr(end_date)]);
disp(['Computational time: ', num2str(time), ' seconds.']);
disp(['Computational time: ', num2str(time / 60), ' minutes.']);
disp(['Computational time: ', num2str(time / 3600), ' hours.']);
disp('*****************************************');
disp(' ');

