
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eric Ghysels, Jonathan B. Hill, and Kaiji Motegi (2018). 
%    Testing a Large Set of Zero Restrictions in Regression Models, 
%         with an Application to Mixed Frequency Granger Causality.
%    Working paper at the University of North Carolina at Chapel Hill
%         and Kobe University.
%
% Main Matlab codes for empirical application on weekly yield spread 
%    and quarterly GDP growth in the U.S.
% Drawing time series plots. 
%
% *****************************************************
% Data:
%    (1) week_data_tsplot_v1.txt
%    (2) quarter_data_tsplot_v1.txt  
% Subroutines directly used in this main code: None.
% Further codes used in the subroutines above: None.
% *****************************************************
%
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University.
% Last updated: February 15, 2018. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all      % erase everything
close all      % close all figures
clc            % clear command window

% default settings for figures
% Font settings are particularly important. Without them there will be an error 
% when you try to open eps files via GS View.
set(0, 'DefaultAxesFontName', 'Helvetica');
set(0, 'DefaultTextFontName', 'Helvetica');
set(0, 'DefaultAxesFontSize', 14); 
set(0, 'DefaultTextFontSize', 14); 
set(gcf,'DefaultLineLineWidth', 1.5);

%% Step 1: Load Data
directory_name = 'E:\SGCTMFD\Mat_Code\';   % where to save figures
version_number = 4;

% load data
load week_data_tsplot_v1.txt
load quarter_data_tsplot_v1.txt
dates_serial_xls = week_data_tsplot_v1(:,1);        % date labels in Excel format
FF = week_data_tsplot_v1(:,2);                      % FF rate
LR = week_data_tsplot_v1(:,3);                      % long-term interest rate
SPR = week_data_tsplot_v1(:,4);                     % spread
recession = week_data_tsplot_v1(:,5);               % recession periods
dates_serial_matlab = x2mdate(dates_serial_xls);    % transform the date labels from Excel format to Matlab format

dates_serial_xls_quarter = quarter_data_tsplot_v1(:,1);              % date labels in Excel format
GDP = quarter_data_tsplot_v1(:,2);                                   % GDP
recession_quarter = quarter_data_tsplot_v1(:,3);                     % recession periods
dates_serial_matlab_quarter = x2mdate(dates_serial_xls_quarter);     % transform the date labels from Excel format to Matlab format

dateFormat = 10;    % format of dates on x-axis 
                    % 10 = 2005; 12 = Jan05.
          
%% Step 2: Draw Figures                    
figure(1)       % FF rate
width = 4;
hold on 
bar(dates_serial_matlab, 25 * recession, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
plot(dates_serial_matlab, FF, '-k', 'LineWidth', 1.8);    
hold off
box on
datetick('x', dateFormat);
xlim([dates_serial_matlab(1), dates_serial_matlab(end)]);
ylim([0, 25]);
file_name = strcat('tsplot_week_FF_v', num2str(version_number));
print('-depsc2', strcat(directory_name, file_name));          

figure(2)      % long-term rate
width = 4;
hold on 
bar(dates_serial_matlab, 25 * recession, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
plot(dates_serial_matlab, LR, '-k', 'LineWidth', 1.8);     
hold off
box on
datetick('x', dateFormat);
xlim([dates_serial_matlab(1), dates_serial_matlab(end)]);
ylim([0, 25]);
file_name = strcat('tsplot_week_10Y_v', num2str(version_number));
print('-depsc2', strcat(directory_name, file_name));          

figure(3)      % yield spread
width = 4;
hold on 
bar(dates_serial_matlab, 10 * recession, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
bar(dates_serial_matlab, -10 * recession, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
plot(dates_serial_matlab, SPR, '-k', 'LineWidth', 1.8);     
hold off
box on
datetick('x', dateFormat);
xlim([dates_serial_matlab(1), dates_serial_matlab(end)]);
ylim([-10, 10]);
file_name = strcat('tsplot_week_SPR_v', num2str(version_number));
print('-depsc2', strcat(directory_name, file_name));          
     
figure(4)      % GDP growth
width = 4;
hold on 
bar(dates_serial_matlab_quarter, 10 * recession_quarter, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
bar(dates_serial_matlab_quarter, -10 * recession_quarter, width, 'FaceColor', [0.9100 0.4100 0.1700], 'LineStyle', 'none');
plot(dates_serial_matlab_quarter, GDP, '-k*', 'LineWidth', 1.8, 'MarkerSize', 4);     
hold off
box on
datetick('x', dateFormat);
xlim([dates_serial_matlab_quarter(1), dates_serial_matlab_quarter(end)]);
ylim([-10, 10]);
file_name = strcat('tsplot_quarter_GDP_v', num2str(version_number));
print('-depsc2', strcat(directory_name, file_name));          


