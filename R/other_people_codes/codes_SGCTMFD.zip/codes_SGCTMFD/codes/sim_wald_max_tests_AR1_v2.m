
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Eric Ghysels, Jonathan B. Hill, and Kaiji Motegi (2018). 
%    Testing a Large Set of Zero Restrictions in Regression Models, 
%         with an Application to Mixed Frequency Granger Causality.
%    Working paper at the University of North Carolina at Chapel Hill
%         and Kobe University.
%
% Main Matlab codes for Monte Carlos simulations with mixed frequency AR(1) setting.
%
% *****************************************************
% Subroutines directly used in this main code:
%    (1) maxtest_all_zeros_v2.m 
%    (2) waldtest_all_zeros_v2.m 
%
% Further codes used in the subroutines above: None.
% *****************************************************
%
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University.
% 
% Last updated: February 15, 2018. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;    % erase everything
clc;          % clear command window

tic;                                           % start timing
start_date = now;                              % start date
disp(['Job started: ', datestr(start_date)]);  % display start date

%% Step 0: Initial Setting
J = 1000;                   % # of Monte Carlo samples
m = 12;                     % ratio of sampling frequencies
h = 100;                     % # of regressors (# of high frequency lags)
T = 50 * h;                 % sample size (low frequency)
DGP_type = 1;               % DGP type = {1, 2, 3, 4}
                            % DGP-1: true_betas = zeros(h,1)
                            % DGP-2: true_betas = b * [(10/h) * ones(0.1*h, 1); zeros(0.9*h,1)]
                            % DGP-3: true_betas = b * [(2/h) * ones(0.5*h, 1); zeros(0.5*h,1)]
                            % DGP-4: true_betas = b * (1/h) * ones(h,1)
                            % DGP-5: true_betas = b * [zeros(0.5*h,1); (2/h) * ones(0.5*h, 1)]
                            % DGP-6: true_betas = b * [zeros(0.9*h,1); (10/h) * ones(0.1*h, 1)]
phi = 0.95;                 % correlation coefficient between an arbitrary pair of regressors
b = 0.05;                   % the impact of X on y
bsnum = 1000;               % # of bootstrap samples (bootstrapped Wald test)
ndraws = 5000;              % # of draws from the limit distribution (max test)
nominal_size = 0.05;        % nominal size

%% Step1: Run Monte Carlo Simulations
mT = m * T;           % sample size (high frequency)
nlag = ceil(h/m);     % lag length in terms of low frequency 
nobs = T - nlag;      % effective sample size

if DGP_type == 1
    true_betas = zeros(h,1);     % true beta
elseif DGP_type == 2
    true_betas = b * [(10/h) * ones(0.1*h, 1); zeros(0.9*h,1)];     % true beta
elseif DGP_type == 3
    true_betas = b * [(2/h) * ones(0.5*h, 1); zeros(0.5*h,1)];     % true beta  
elseif DGP_type == 4
    true_betas = b * (1/h) * ones(h,1);     % true beta
elseif DGP_type == 5
    true_betas = b * [zeros(0.5*h,1); (2/h) * ones(0.5*h, 1)];     % true beta  
elseif DGP_type == 6    
    true_betas = b * [zeros(0.9*h,1); (10/h) * ones(0.1*h, 1)];     % true beta    
end

rejections_max_homo = zeros(J,1);
rejections_max_hetero = zeros(J,1);
rejections_wald_asy = zeros(J,1);
rejections_wald_bs = zeros(J,1);
parfor j = 1:J
%for j = 1:J
     % generate high frequency variable
     epsilon_H = randn(mT,1);
     x_H = zeros(mT,1);
     for t = 2:mT
          x_H(t) = phi * x_H(t-1) + epsilon_H(t);     % high frequency AR(1)
     end    
     
     % generate low frequency variable
     epsilon_L = randn(T,1);
     x_L = zeros(T,1);
     for tau = 2:T
          t_newest = (tau - 1) * m;
          t_oldest = t_newest - h + 1;
          if t_oldest >= 1
              x_H_temp = x_H(t_oldest:t_newest);
              x_L(tau) = true_betas' * flipud(x_H_temp) + epsilon_L(tau);
          else
              x_H_temp = x_H(1:t_newest);
              x_L(tau) = true_betas(1:t_newest)' * flipud(x_H_temp) + epsilon_L(tau);
          end    
     end    
     
     % construct regressand and regressors
     x_H_mat = reshape(x_H, m, T)';
     y = x_L((nlag + 1):T);
     X = zeros(nobs, h);
     for tau = 1:nobs
          counter_LF = 0;
          counter_HF = 0;
          for k = 1:h
               X(tau,k) = x_H_mat(nlag + tau - 1 - counter_LF, m - counter_HF);
               if m - counter_HF == 1
                   counter_HF = 0;
                   counter_LF = counter_LF + 1; 
               else
                   counter_HF = counter_HF + 1;
               end    
          end              
     end    
     
     % run max test with the assumption of conditional homoskedasticity
     maxtest_hetero_flag = 0;
     [~, p_value_max_homo] = maxtest_all_zeros_v2(y, X, ndraws, maxtest_hetero_flag);
     rejections_max_homo(j) = (p_value_max_homo < nominal_size);

     % run max test without the assumption of conditional homoskedasticity
     maxtest_hetero_flag = 1;
     [~, p_value_max_hetero] = maxtest_all_zeros_v2(y, X, ndraws, maxtest_hetero_flag);
     rejections_max_hetero(j) = (p_value_max_hetero < nominal_size);     
     
     % run asymptotic Wald test 
     [wald_stat_asy, p_value_wald_asy] = waldtest_all_zeros_v2(y, X, 0);
     rejections_wald_asy(j) = (p_value_wald_asy < nominal_size);

     % run bootstrapped Wald test
      [wald_stat_bs, p_value_wald_bs] = waldtest_all_zeros_v2(y, X, bsnum);
      rejections_wald_bs(j) = (p_value_wald_bs < nominal_size);
end    

% compute rejection frequencies
rfreq_max_homo = (1/J) * sum(rejections_max_homo);
rfreq_max_hetero = (1/J) * sum(rejections_max_hetero);
rfreq_wald_asy = (1/J) * sum(rejections_wald_asy);
rfreq_wald_bs = (1/J) * sum(rejections_wald_bs);
rfreq_table = [rfreq_max_homo; rfreq_max_hetero; rfreq_wald_asy; rfreq_wald_bs];

%% Step 2: Report Computational Time 
time = toc;      % finish timing
end_date = now;  % end date
disp('*****************************************');
disp(['Job started: ', datestr(start_date)]);
disp(['Job finished: ', datestr(end_date)]);
disp(['Computational time: ', num2str(time), ' seconds.']);
disp(['Computational time: ', num2str(time / 60), ' minutes.']);
disp(['Computational time: ', num2str(time / 3600), ' hours.']);
disp('*****************************************');
disp(' ');

