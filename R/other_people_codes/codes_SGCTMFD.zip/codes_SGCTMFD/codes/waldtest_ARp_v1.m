function [wald_stat, p_value] = waldtest_ARp_v1(y, X, p, bsnum)
% PURPOSE: Run Wald test with AR(p) terms and key regressors X.         
%--------------------------------------------------------------------
% USAGE: [wald_stat, p_value] = waldtest_ARp_v1(y, X, p, bsnum)
% where: y = regressand (n x 1) 
%                  n = sample size
%        X = key regressors (n x h)
%                  h = dimension of key regressors (large)
%                  H0: all of X has zero coefficients
%        p = AR lag length (1 x 1)
%        bsnum = # of bootstrap samples (scalar)
%                0 for asymptotic Wald test
%--------------------------------------------------------------------
% RETURNS: wald_stat = test statistic (scalar)
%          pval = asymptotic or bootstrapped p-value (scalar)
%--------------------------------------------------------------------
% References: 
%    S. Goncalves and L. Kilian (2004). Bootstrapping Autoregressions with 
%        Conditional Heteroskedasticity of Unknown Form. Journal of
%        Econometric, 123, 89-120.
%    E. Ghysels, J. B. Hill, and K. Motegi (2018).  
%        Testing a Large Set of Zero Restrictions in Regression Models, 
%        with an Application to Mixed Frequency Granger Causality. 
%        Working paper at the University of North Carolina at Chapel Hill
%        and Kobe University.
% -------------------------------------------------------------------
% Model: y(t) = c + alpha(1) * y(t-1) + ... + alpha(p) * y(t-p)
%                 + beta(1) * x(1t) + ... + beta(h) * x(ht) + u(t)
% --------------------------------------------------------------------
% See also: chi2cdf.m (Statistics and Machine Learning Toolbox)
% --------------------------------------------------------------------
% Written by Kaiji Motegi.
% Graduate School of Economics, Kobe University. 
% December 29, 2018. 
% --------------------------------------------------------------------

% generic function that computes Wald statistic
function [wald_stat, resid, theta_hat, n, p, h] = wald_test_stat(y, X, p)
    n = size(X,1);
    h = size(X,2);
    nobs = n - p;
    nvar = h + p + 1;
    Z = zeros(nobs, p+1);
    Z(:,1) = ones(nobs,1);
    for k = 1:p
         Z(:,k+1) = y((p+1-k):(n-k));    % AR terms
    end    
    regressand = y((p+1):n);
    regressors = [Z, X((p+1):n,:)];
    theta_hat = regressors \ regressand;                % run OLS
    resid = regressand - regressors * theta_hat;
    sigsq_hat = (1/nobs) * sum(resid.^2);
    Sigma_hat = (1/nobs) * (regressors' * regressors);
    Sigma_hat_inv = Sigma_hat \ eye(nvar);
    AVar = sigsq_hat * Sigma_hat_inv;
    R = [zeros(h,p+1), eye(h)];          % selection matrix (h x (h+p+1))
    RAR = R * AVar * R';
    RAR_inv = RAR \ eye(h);
    beta_hat = R * theta_hat;
    wald_stat = nobs * beta_hat' * RAR_inv * beta_hat;    % Wald statistic
end

% compute actual Wald statistic
[wald_stat, resid, theta_hat, n, p, h] = wald_test_stat(y, X, p);

if bsnum == 0    % asymptotic test
    p_value = 1 - chi2cdf(wald_stat, h);   % asymptotic p-value
else             % bootstrapped test
    counter = 0;
    nn = n - p;
    for j = 1:bsnum
         xi = randn(nn,1);
         xi_epsilon = xi .* resid;    % Goncalves and Kilian (2004)
         y_bs = zeros(n,1);
         y_bs(1:p) = y(1:p);
         for t = (p+1):n
              y_bs_temp = theta_hat(1) + xi_epsilon(t-p);
              for i = 1:p
                   y_bs_temp = y_bs_temp + theta_hat(1+i) * y_bs(t-i);
              end    
              y_bs(t) = y_bs_temp;
         end    
         wald_stat_bs = wald_test_stat(y_bs, X, p);      % run Wald test
         counter = counter + (wald_stat_bs > wald_stat);
    end     
    p_value = (1/bsnum) * counter;    % bootstrapped p-value
end

end
    
