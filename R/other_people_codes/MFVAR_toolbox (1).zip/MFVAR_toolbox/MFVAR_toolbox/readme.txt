

This zip file contains eleven m-files for estimating Ghysels' (2012) mixed frequency vector autoregression 
and implementing related analysis like impulse response functions, forecast error variance decomposition, 
and Ghysels, Hill, and Motegi's (2013) mixed frequency Granger causality tests.


MFVAR_example.m is the main m-file illustrating all these tools via an artificial trivariate example.


Written by Kaiji Motegi, Waseda University.
September 9, 2014. 
