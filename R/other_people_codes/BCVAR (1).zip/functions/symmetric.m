function [B] = symmetric(A)
% sym : Create symmetric matrix B from square matrix A
p = size(A,1);
B=A;
for i=1:p
    for j=i+1:p
        B(i,j) = A(j,i);
    end
end