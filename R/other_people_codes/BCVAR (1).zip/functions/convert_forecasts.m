function [y] = convert_forecasts(x,xi,h)

y = 0*x;
for i = 1:h    
    if i == 1
        y(:,i) = xi + x(:,i);
    else
        y(:,i) = y(:,i-1) + x(:,i);
    end
end
    