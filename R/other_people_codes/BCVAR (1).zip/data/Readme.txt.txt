Note: Variable transformations updated as suggested by Dimitris on November 4, 2015 - only using 1, 4 and 5.
